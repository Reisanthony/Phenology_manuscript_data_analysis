This folder contains the long term dataset, including presence/absence records for all butterfly species at each site from 1985 to 2023, species natural history traits and climate data. It also includes an R script for merging Daymet climate data with butterfly presence/absence observations.



Daymet daily climate data (1985–2023)

The following five files contain daily climate data downloaded from Daymet for each study site.

castle_peak_daymet_climate_data.csv

donner_pass_daymet_climate_data.csv

lang_crossing_daymet_climate_data.csv

sierra_valley_daymet_climate_data.csv

washington_daymet_climate_data.csv

Variable	Description

year	Calendar year of the observation.

day	Day of year (1–365 or 1–366 in leap years).

daylength	Length of daylight in seconds for that location and day.

prcp	Daily total precipitation (mm).

srad	Daily shortwave solar radiation (W/m²).

swe	Snow Water Equivalent (kg/m²); water content of the snowpack.

tmax	Daily maximum air temperature (°C).

tmin	Daily minimum air temperature (°C).

vp	Water vapor pressure (Pa).




Montane_sites_2023.csv

This file contains long term biweekly presence/absence data for five montane butterfly communities (1985–2023).

Variable	Description

site_name	Name of the site where data was collected.

visit_date	Date the site was surveyed.

genus_species	Scientific name of the species.

pa	Presence (1) or absence (0) of the species.

ordDate	Day of year (1–365 or 1–366 in leap years).

Year	Calendar year of the observation.

Month	Month of the observation (1–12).

Observer	Name of the observer(s) who collected data on that visit.



natural_history_2024.csv

This file contains natural history trait data for all butterfly species recorded at each site.

Variable	Description

genus_species	Scientific name of the species.

site_name	Site where natural history information was recorded.

broods	Number of broods per year at that site.

weedy	Whether the species is considered ruderal at that site.

hostgenera	Number of host plant genera used at that site.

hostfamily	Number of host plant families used at that site.

resident	Whether the species overwinters and breeds at the site.

wintering	Overwintering life stage (adult, egg, pupa, larva).



COMBINING_CLIMATE_DATA_AND_BUTTERFLY_DATA.R

This R script summarizes Daymet climate variables and merges them with the long term butterfly presence/absence dataset.




Montane_sites_2023_with_Daymet_data.csv

This combined dataset merges biweekly butterfly observations with summary climate variables from Daymet.


All variables from Montane_sites_2023.csv and the below:

Variable	Description

spring_prcp	Mean daily precipitation in the current year’s spring season.

spring_tmax	Mean daily maximum temperature in spring.

spring_tmin	Mean daily minimum temperature in spring.

prevfall_prcp	Mean daily precipitation in the previous year’s fall season.

prevfall_tmax	Mean daily maximum temperature in previous fall.

prevfall_tmin	Mean daily minimum temperature in previous fall.

winter_prcp	Mean daily precipitation in the current year’s winter season.

winter_tmax	Mean daily maximum temperature in winter.

winter_tmin	Mean daily minimum temperature in winter.

swe_mean	Mean daily Snow Water Equivalent for the current water year.

swe_sd	Standard deviation of daily Snow Water Equivalent for the current water year.

estGdd	Estimated growing degree days.


