#COMBING CLIMATE DATA AND BUTTERFLY DATA


#package for GDD
library(pollen)

# read in the butterfly data
dat<-read.csv("Montane_sites_2023.csv")
dat <- dat[,-c(9,10,11)]
new_dat <-c()
  
Daymet_data <- c("castle_peak_daymet_climate_data.csv",
"donner_pass_daymet_climate_data.csv",
"lang_crossing_daymet_climate_data.csv",
"sierra_valley_daymet_climate_data.csv",
"washington_daymet_climate_data.csv")

#for joining together at the end
new_dat <-c()
#for selecting sites
num <- 1:5

for (k in 1:5) {
  datcs<-read.csv(Daymet_data[k]) 
  
  #############################
  #Climate summaries
  #############################
  allyr <- unique(datcs$year)
  
  #current year spring climate
  spring_prcp <- c()
  spring_tmax <- c()
  spring_tmin <- c()
  spring_daylength <- c()
  spring_srad <- c()
  spring_swe <- c()
  
  #previus year fall climate 
  prevfall_prcp <- c()
  prevfall_tmax <- c()
  prevfall_tmin <- c()
  prevfall_daylength <- c()
  prevfall_srad <- c()
  prevfall_swe <- c()
  
  
  #winter climate 
  winter_prcp <- c()
  winter_tmax <- c()
  winter_tmin <- c()
  
  #snow water year
  swe_mean <- c()
  swe_sd <- c()
  
  for (i in 1:length(allyr)) {
    #current year spring climate
    a <- which(datcs$year== allyr[i])
    sp <- datcs[a, ]
    spring <- sp[which(sp$day %in% c(60:151)), ]
    spring_prcp[i] <- mean(spring$prcp)
    spring_tmax[i] <- mean(spring$tmax)
    spring_tmin[i] <- mean(spring$tmin)
    
    #previus year fall climate 
    b <- which(datcs$year== allyr[i-1])
    fa <- datcs[b, ]
    prevfall <- fa[which(fa$day %in% c(244:334)), ]
    prevfall_prcp[i] <- mean(prevfall$prcp)
    prevfall_tmax[i] <- mean(prevfall$tmax)
    prevfall_tmin[i] <- mean(prevfall$tmin)
    
    #winter whhich starts from december of the previous year to February of that year
    winter <- datcs[(datcs$day >= 335 & datcs$year == allyr[i-1]) | (datcs$day <= 59 & datcs$year == allyr[i]), ]
    winter_prcp[i] <- mean(winter$prcp)
    winter_tmax[i] <- mean(winter$tmax)
    winter_tmin[i] <- mean(winter$tmin)
    
    #snow water year (sep1st of the previous yer to may 31 of the following year)
    swe_yr <- datcs[(datcs$day >= 244 & datcs$year == allyr[i-1]) | (datcs$day <=151 & datcs$year == allyr[i]), ]
    swe_mean[i] <- mean(swe_yr$swe)
    swe_sd[i] <- sd(swe_yr$swe)
  }
  
  
  #create data frame CONTAING ALL CLIMATE SUMMARY
  Year <- allyr
  climate <- cbind(Year, 
                   spring_prcp, spring_tmax, spring_tmin, 
                   prevfall_prcp, prevfall_tmax, prevfall_tmin, 
                   winter_prcp, winter_tmax, winter_tmin, 
                   swe_mean, swe_sd)
  
  
  #############################
  #Estimate Growing degree days
  #############################
  
  ## create vector to store gdd
  N<-dim(datcs)[1] ## number of observations total
  estGdd<-rep(NA,N)
  
  ## loop over years
  for(i in 1:length(allyr)){
    ayr<-which(datcs$year==allyr[i]) ## get data for year i
    estGdd[ayr] <- gdd(tmax = datcs$tmax[ayr], tmin = datcs$tmin[ayr], 
                       tbase = 10, tbase_max = 30, type = "D")
  }
  
  ## visualize gdd accumulation each year
  plot(datcs$day,estGdd,pch=19,xlab="Ordinal day",ylab="GDD")
  
  ##GDD at May 31 for that year
  c <- which(datcs$day == 151)
  estGdd <- estGdd[c]
  
  #MERGE other climate summaries with GDD 
  climate <- cbind(climate, estGdd)
  
  
  
  #combine all climate summaries and butterfly data for each site
  
  table(dat$site_name)
  
  #  Castle Peak   Donner Pass Lang Crossing Sierra Valley    Washington 
  #        41890        103477        102832        101514        108523
  
  sites<-unique(dat$site_name)
  myargs<-commandArgs(trailingOnly=TRUE)
  j<-as.numeric(myargs[1])
  # "Castle Peak"   "Donner Pass"   "Lang Crossing" "Sierra Valley" "Washington" 
  j<- num[k]
  cat("working on site",sites[j],"\n")
  sub_dat<-dat[dat$site_name==sites[j],]
  sp<-unique(sub_dat$genus_species)
  
  ##for merging climate summaries and GDD
  sub_dat = merge(climate, sub_dat, by = c("Year"), all.y = T )
  
  new_dat <- rbind(new_dat, sub_dat)
    
}

write.csv(new_dat, file = "Montane_sites_2023_with_Daymet_data.csv", row.names = FALSE)

